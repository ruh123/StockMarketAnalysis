# An object of Flask class is our WSGI application.
from flask import Flask, render_template
import pymongo

# Flask constructor takes the name of
# current module (__name__) as argument.
app = Flask(__name__)

# The route() function of the Flask class is a decorator,
# which tells the application which URL should call
# the associated function.
@app.route('/')
def home():
    # main driver function
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    # Database Name
    db = client["StocksDB"]
    # Collection Name
    col = db["stock_data"]
    x = col.find({"currency": {"$exists": False}})
    return render_template('home.html', homedata=x)
@app.route('/StocksDashboard/')
def StocksDashboard():
    return render_template('StocksDashboard.html')
if __name__ == '__main__':
    # run() method of Flask class runs the application
    # on the local development server.
    app.run()
